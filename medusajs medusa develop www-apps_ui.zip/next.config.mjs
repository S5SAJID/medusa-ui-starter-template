import mdx from "@next/mdx"
import path from "path"
import rehypeMdxCodeProps from "rehype-mdx-code-props"
import rehypeSlug from "rehype-slug"
import remarkDirective from "remark-directive"
import remarkFrontmatter from "remark-frontmatter"
import {
  brokenLinkCheckerPlugin,
  localLinksRehypePlugin,
  cloudinaryImgRehypePlugin,
  resolveAdmonitionsPlugin,
  crossProjectLinksPlugin,
  prerequisitesLinkFixerPlugin,
  remarkAttachFrontmatterDataPlugin,
  recmaInjectMdxDataPlugin,
  validateHighlightsPlugin,
  uiRehypePlugin,
} from "remark-rehype-plugins"
import bundleAnalyzer from "@next/bundle-analyzer"
import withExtractedTableOfContents from "@stefanprobst/rehype-extract-toc"
import { ExampleRegistry } from "./specs/examples.mjs"
import { ComponentSpecsIndex } from "./generated/components-index.mjs"

const withMDX = mdx({
  extension: /\.mdx?$/,
  options: {
    rehypePlugins: [
      [
        brokenLinkCheckerPlugin,
        {
          crossProjects: {
            docs: {
              projectPath: path.resolve("..", "book"),
            },
            cloud: {
              projectPath: path.resolve("..", "cloud"),
            },
            resources: {
              projectPath: path.resolve("..", "resources"),
              hasGeneratedSlugs: true,
            },
            api: {
              projectPath: path.resolve("..", "api-reference"),
              skipSlugValidation: true,
            },
            "user-guide": {
              projectPath: path.resolve("..", "user-guide"),
            },
          },
        },
      ],
      [
        crossProjectLinksPlugin,
        {
          baseUrl: process.env.NEXT_PUBLIC_BASE_URL,
          projectUrls: {
            docs: {
              url: process.env.NEXT_PUBLIC_DOCS_URL,
              path: "",
            },
            resources: {
              url: process.env.NEXT_PUBLIC_RESOURCES_URL,
            },
            cloud: {
              url: process.env.NEXT_PUBLIC_CLOUD_URL,
            },
            api: {
              url: process.env.NEXT_PUBLIC_API_URL,
            },
            "user-guide": {
              url: process.env.NEXT_PUBLIC_USER_GUIDE_URL,
            },
          },
          useBaseUrl:
            process.env.NODE_ENV === "production" ||
            process.env.VERCEL_ENV === "production" ||
            !!process.env.CLOUDFLARE_ENV,
        },
      ],
      [localLinksRehypePlugin],
      [
        rehypeMdxCodeProps,
        {
          tagName: "code",
        },
      ],
      [validateHighlightsPlugin, { verbose: false }],
      [rehypeSlug],
      [
        cloudinaryImgRehypePlugin,
        {
          cloudinaryConfig: {
            cloudName: process.env.CLOUDINARY_CLOUD_NAME || "",
            flags: ["fl_lossy", "f_auto"],
            resize: {
              action: "pad",
              aspectRatio: "16:9",
            },
            roundCorners: 16,
          },
        },
      ],
      [
        prerequisitesLinkFixerPlugin,
        {
          checkLinksType: "value",
        },
      ],
      [withExtractedTableOfContents],
      [
        uiRehypePlugin,
        {
          exampleRegistry: ExampleRegistry,
          specsIndex: ComponentSpecsIndex,
          specsBaseUrl: process.env.UI_SPECS_R2_BASE_URL,
        },
      ],
    ],
    remarkPlugins: [
      [remarkFrontmatter],
      [remarkDirective],
      [resolveAdmonitionsPlugin],
      [remarkAttachFrontmatterDataPlugin],
    ],
    recmaPlugins: [[recmaInjectMdxDataPlugin]],
    jsx: true,
  },
})

/** @type {import('next').NextConfig} */
const nextConfig = {
  // Configure `pageExtensions` to include MDX files
  pageExtensions: ["js", "jsx", "mdx", "ts", "tsx"],

  transpilePackages: ["docs-ui"],
  basePath: process.env.NEXT_PUBLIC_BASE_PATH || "/ui",
  outputFileTracingRoot: new URL("../../", import.meta.url).pathname,
  outputFileTracingIncludes: {
    "/md\\-content/\\[\\[\\.\\.\\.slug\\]\\]": [
      "./app/**/*.mdx",
      "./specs/**/*",
      "./examples/**/*",
    ],
  },
  outputFileTracingExcludes: {
    "*": [
      "node_modules/@medusajs/icons",
      "../**/.open-next/**",
      "../!(ui)/.next/**",
    ],
  },
  experimental: {
    optimizePackageImports: ["@medusajs/icons", "@medusajs/ui"],
  },
  rewrites: async () => {
    return {
      beforeFiles: [
        {
          source: "/index.html.md",
          destination: "/md-content",
        },
        {
          source: "/index.md",
          destination: "/md-content",
        },
        {
          source: "/:path*/index.html.md",
          destination: "/md-content/:path*",
        },
        {
          source: "/:path*/index.md",
          destination: "/md-content/:path*",
        },
        {
          source: "/:path*.md",
          destination: "/md-content/:path*",
        },
        {
          source: "/:first((?!md-content)[^/]+)/:rest*/",
          has: [
            {
              type: "header",
              key: "Accept",
              value: ".*(text/markdown|text/plain).*",
            },
          ],
          destination: "/md-content/:first/:rest*",
        },
        {
          source: "/",
          has: [
            {
              type: "header",
              key: "Accept",
              value: ".*(text/markdown|text/plain).*",
            },
          ],
          destination: "/md-content",
        },
        {
          source: "/:first((?!md-content)[^/]+)/:rest*",
          has: [
            {
              type: "header",
              key: "Accept",
              value: ".*(text/markdown|text/plain).*",
            },
          ],
          destination: "/md-content/:first/:rest*",
        },
      ],
    }
  },
}

const withBundleAnalyzer = bundleAnalyzer({
  enabled: process.env.ANALYZE === "true",
})

export default withMDX(withBundleAnalyzer(nextConfig))
